package com.example.demo.service;

import com.example.demo.controller.RespuestaFibonacciDTO;

public interface FibonacciService {
    
    RespuestaFibonacciDTO entregarSerie();

}
